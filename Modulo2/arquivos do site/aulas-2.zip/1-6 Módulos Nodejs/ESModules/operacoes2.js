function multiplicacao(a, b) {
    return a * b;
}

export default multiplicacao;