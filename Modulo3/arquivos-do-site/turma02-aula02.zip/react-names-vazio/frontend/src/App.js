import React from 'react';

export default function App() {
  return (
    <div>
      <h1 className='center'>React Names</h1>
    </div>
  );
}
