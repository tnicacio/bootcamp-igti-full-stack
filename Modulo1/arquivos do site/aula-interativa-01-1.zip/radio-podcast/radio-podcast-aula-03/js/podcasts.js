var realPodcasts = [
  {
    id: '88.5',
    title: 'Syntax',
    description:
      '[Inglês] Desenvolvimento JavaScript em geral. Apresentado por Wes Bos e Scott Tolinksi',
    img: '1.png',
  },
  {
    id: '90.1',
    title: 'FalaDev',
    description:
      'Desenvolvimento JavaScript em geral. Apresentado pelo pessoal da Rocketseat.',
    img: '2.jpg',
  },
  {
    id: '92.3',
    title: 'Lambda3',
    description:
      'Desenvolvimento e diversidade. Apresentado pelo pessoal da Lambda3',
    img: '3.jpg',
  },
  {
    id: '93.9',
    title: 'DevNaEstrada',
    description:
      'Desenvolvimento em geral e histórias de carreira de desenvolvedores.',
    img: '4.png',
  },
  {
    id: '95.8',
    title: 'Hipsters.tech',
    description:
      'Desenvolvimento em geral. Apresentado pelo pessoal da Caelum/Alura.',
    img: '5.png',
  },
  {
    id: '98.3',
    title: 'NerdCast',
    description: 'Cultura Nerd. Apresentado pelo Jovem Nerd e Azhagal.',
    img: '6.jfif',
  },
  {
    id: '100.4',
    title: 'Área de Transferência',
    description: 'Tecnologia em geral.',
    img: '7.png',
  },
  {
    id: '105.3',
    title: 'Tecnocast',
    description: 'Tecnologia em geral. Apresentado pelo pessoal do Tecnoblog',
    img: '8.jpg',
  },
];
